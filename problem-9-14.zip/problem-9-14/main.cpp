#include <iostream>
using namespace std;

#include "hugeinteger.cpp"



int main() {
    HugeInteger h1("h1");
    HugeInteger h2("h2");
    h1.display();
    h2.display();
    cout<<endl<<endl;
    string n1 ="127";
    string n2 = "985";
    h1.input(n1);
    h2.input(n2);
    h1.display();
    h2.display();
    HugeInteger h3 = h1.add(h2);
    h3.display();
    return 0;
}
