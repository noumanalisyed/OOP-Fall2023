//
// Created by nouman on 10/31/2023.
//

#ifndef PROBLEM_9_14_HUGEINTEGER_H
#define PROBLEM_9_14_HUGEINTEGER_H
#include<iostream>
using namespace std;

class HugeInteger {
public:
    HugeInteger(string n);
    void input(string data);
    HugeInteger add(HugeInteger h);
    HugeInteger sub(HugeInteger h);
    void display();
    int getSize();
private:
    void init();
    const int size = 40;
    int *ptr;
    string name;
    char sign;
};
#endif //PROBLEM_9_14_HUGEINTEGER_H
