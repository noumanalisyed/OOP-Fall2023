//
// Created by nouman on 10/31/2023.
//
#include "hugeinteger.h"

HugeInteger::HugeInteger(string n){
    name = n;
    ptr = new int[size];
    sign = '+';
    init();
}
void HugeInteger::input(string data){
    int stringSize = data.length();
    for (int i = size-1, j = stringSize -1; i >= 0 ; --i) {
        if( j >= 0){
            ptr[i] = data[j] - 48;
            j--;
        }
    }
}

void HugeInteger::display(){
    bool flag1 = false, flag2 = false;
    cout<<name<<" = ";
    for (int i = 0; i < size; ++i) {
        if(ptr[i] == 0  && flag2 == false){
            flag1 = false;
        }
        else{
            flag1 = true;
            flag2 = true;
        }
        if(flag1 == true && flag2 == true) {
            cout << ptr[i] << " ";
        }
    }
    cout<<endl;
}
int HugeInteger::getSize(){
    return size;
}


void HugeInteger::init(){
    for (int i = 0; i < size; ++i) {
        ptr[i] = 0;
    }
}

HugeInteger HugeInteger::add(HugeInteger h){
    HugeInteger result("Sum");
    int n = 0, c = 0, d = 10 , r = 0;
    for (int i = size-1; i >= 0; i--) {
        n = ptr[i] + h.ptr[i] + c;
        if(n >= 10){
            c = n / d;
            r = n % d;
            result.ptr[i] = r;
        }else{
            result.ptr[i] = n;
            c = 0 ;
        }
    }
    return result;
}
HugeInteger HugeInteger::sub(HugeInteger h){
    HugeInteger result("Sum");
    int n = 0, c = 0, d = 10 , r = 0;
    for (int i = size-1; i >= 0; i--) {
        n = ptr[i] + h.ptr[i] + c;
        if(n >= 10){
            c = n / d;
            r = n % d;
            result.ptr[i] = r;
        }else{
            result.ptr[i] = n;
            c = 0 ;
        }
    }
    return result;
}